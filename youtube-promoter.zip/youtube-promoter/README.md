# AI-Powered YouTube Video Promoter

An ultra-smart AI application to mass promote YouTube videos for thousands of views using advanced intelligence.

## Features
- **Ultra-Smart AI**: Predictive analytics, viral scoring, and dynamic optimization.
- **Easy Link Input**: Paste a YouTube URL and let AI handle everything.
- **Comprehensive Promotion**: Automated enhancements, social sharing, and trend analysis.
- **Real-Time Dashboard**: Track results and predictions.

## Setup
1. **Install Dependencies**:
   - Root: `npm install`
   - Frontend: `npm run install-client`
   - Backend: `npm run install-server`

2. **Environment Variables**:
   - Add your OpenAI API key to `.env` (OPENAI_API_KEY=your_key_here)

3. **Run the App**:
   - Start backend: `npm run server`
   - Start frontend: `npm run client` (in another terminal)
   - Or for development: `npm run dev`

4. **Launch**:
   - Open `index.html` in your browser to start.

## Usage
1. Open the app via `index.html` or directly at `http://localhost:3000`.
2. Paste your YouTube video URL in the promoter form.
3. Click "Promote with AI" – the AI will analyze, optimize, and promote for maximum views.

## Notes
- This is a demo; for production, integrate real APIs (YouTube Data API, social media APIs).
- AI optimizes for better performance, but views depend on content and audience.
- Ensure compliance with YouTube's Terms of Service.

## Tech Stack
- Backend: Node.js, Express, MongoDB, OpenAI API
- Frontend: React, Axios
- AI: GPT-4 for content generation and analysis
