import React, { useState } from 'react';
import axios from 'axios';
import VideoPromoter from './components/VideoPromoter';
import Dashboard from './components/Dashboard';
import './styles.css';

function App() {
  const [promotionResult, setPromotionResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handlePromotion = async (videoUrl) => {
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/promotion/promote', { videoUrl });
      setPromotionResult(res.data);
    } catch (err) {
      console.error(err);
      alert('Error promoting video');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Ultra-Smart AI YouTube Promoter</h1>
        <p>Get thousands of views with advanced AI intelligence!</p>
      </header>
      <main>
        <VideoPromoter onPromote={handlePromotion} loading={loading} />
        {promotionResult && <Dashboard result={promotionResult} />}
      </main>
    </div>
  );
}

export default App;
