import React, { useState } from 'react';

const VideoPromoter = ({ onPromote, loading }) => {
  const [videoUrl, setVideoUrl] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (videoUrl) {
      onPromote(videoUrl);
      setVideoUrl('');
    }
  };

  return (
    <div className="video-promoter">
      <h2>Promote Your YouTube Video</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="url"
          placeholder="Paste YouTube video URL here"
          value={videoUrl}
          onChange={(e) => setVideoUrl(e.target.value)}
          required
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Promoting...' : 'Promote with AI'}
        </button>
      </form>
      <p>Our ultra-smart AI will analyze and promote your video for maximum views!</p>
    </div>
  );
};

export default VideoPromoter;
