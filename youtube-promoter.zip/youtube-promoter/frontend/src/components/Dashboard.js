import React from 'react';

const Dashboard = ({ result }) => {
  if (!result) return null;

  return (
    <div className="dashboard">
      <h2>Promotion Results</h2>
      <div className="results">
        <p><strong>Status:</strong> {result.message}</p>
        <div className="section">
          <h3>AI Analysis</h3>
          <p>{result.analysis}</p>
        </div>
        <div className="section">
          <h3>Enhancements</h3>
          <p>{result.enhancements}</p>
        </div>
        <div className="section">
          <h3>Promotion Strategy</h3>
          <p>{JSON.stringify(result.strategy, null, 2)}</p>
        </div>
        <div className="section">
          <h3>Results</h3>
          <p>Shares: {result.promotionResults.shares}</p>
          <p>Engagements: {result.promotionResults.engagements}</p>
        </div>
        <div className="section">
          <h3>Predicted Views</h3>
          <p>{result.predictions.predictedViews} (Confidence: {result.predictions.confidence})</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
