const express = require('express');
const router = express.Router();
const { promoteVideo } = require('../services/aiService');

// @route   POST /api/promotion/promote
// @desc    Promote a YouTube video
// @access  Public (for demo)
router.post('/promote', async (req, res) => {
  try {
    const { videoUrl } = req.body;
    if (!videoUrl) {
      return res.status(400).json({ msg: 'Video URL is required' });
    }

    // Call AI service to promote the video
    const result = await promoteVideo(videoUrl);

    res.json(result);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;
